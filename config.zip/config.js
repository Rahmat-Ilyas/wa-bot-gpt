module.exports = {
    API_KEY_AI: "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"
}
