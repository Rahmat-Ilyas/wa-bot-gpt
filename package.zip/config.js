module.exports = {
    API_KEY_AI: "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"
}
